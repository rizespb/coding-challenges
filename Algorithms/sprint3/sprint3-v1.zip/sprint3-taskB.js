// ID успешной посылки 95611642

/*
-- ПРИНЦИП РАБОТЫ --

Я реализовал сортировку участников соревнований на основе алгоритма in-place quick sort

Это рекурсивный алгоритм сортировки. На каждом уровне рекурсии выбирается опорный элемент (середина массива). Используется два указателя - левый и правый. Мы начинаем перемещать указатели (левый вправо и правый влево) до тех пор, пока слева не окажется элемент больше опорного, а справа - меньше опорного. В этот момент меняем элементы местами. Продолжаем двигать указатели, пока они не «столкнуться»

Для сравнения элемента сопорным используется функция compare, которая вначале сравнивает участников по количеству решенных задача, помещая в левую часть массива элеметы с большим показателем. Если эти показатели равны, то функция сравнивает элементы по количеству штрафных баллов (в левую часть идут участники с меньшим количеством баллов, в правую - с большим). Если и эти показатели равны, то происходит лексографическое сравнение имен участников

-- ВРЕМЕННАЯ СЛОЖНОСТЬ --
Сортировка осуществляется со сложносью О(n * log n)

-- ПРОСТРАНСТВЕННАЯ СЛОЖНОСТЬ --
Алгоритм сортируем элементы «на месте».
Поэтому программа будет потреблять O(1) дополнительной памяти, если считать, что входной массив формируется за пределами программы. Или O(n), если считать память, занимаемую входным массивом, частью программы.
*/

const _readline = require('readline')

const _reader = _readline.createInterface({
  input: process.stdin,
})

const _inputLines = []

_reader.on('line', (line) => {
  _inputLines.push(line)
})

process.stdin.on('end', solve)

const compare = (a, b) => {
  if (a[1] !== b[1]) {
    return a[1] > b[1]
  } else if (b[2] !== a[2]) {
    return b[2] > a[2]
  } else {
    return a[0] < b[0]
  }
}

function quickSortInPlace(arr, left = 0, right = arr.length - 1) {
  if (arr.length < 2) return

  const index = partition(arr, left, right)

  if (left < index - 1) {
    quickSortInPlace(arr, left, index - 1)
  }
  if (right > index) {
    quickSortInPlace(arr, index, right)
  }
}

function partition(arr, left, right) {
  const pivotIndex = Math.floor((left + right) / 2)

  const pivot = arr[pivotIndex]

  while (left <= right) {
    while (compare(arr[left], pivot)) {
      left++
    }

    while (compare(pivot, arr[right])) {
      right--
    }

    if (left <= right) {
      ;[arr[left], arr[right]] = [arr[right], arr[left]]

      left++
      right--
    }
  }
  return left
}

const convertData = (arr) => arr.map((item) => item.split(' ').map((el, index) => (index === 0 ? el : Number(el))))

function solve() {
  const arrayLength = Number(_inputLines[0])
  const data = _inputLines.slice(1, 1 + arrayLength)
  const input = convertData(data)

  quickSortInPlace(input)

  input.forEach((el) => console.log(el[0]))
}

solve()
