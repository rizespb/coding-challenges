// ID успешной посылки 94692948

const _readline = require('readline')

const _reader = _readline.createInterface({
  input: process.stdin,
})

const _inputLines = []

_reader.on('line', (line) => {
  _inputLines.push(line)
})

process.stdin.on('end', solve)

function solve() {
  const buttons = Number(_inputLines[0]) * 2
  const str = _inputLines.slice(1).join('')

  const map = {}

  for (let i = 0; i < str.length; i++) {
    if (str[i] === '.') {
      continue
    }

    if (!map[str[i]]) map[str[i]] = 0

    map[str[i]]++
  }

  let counter = 0

  for (const key in map) {
    if (map[key] <= buttons) {
      counter++
    }
  }

  console.log(counter + '')
}
