// ID успешной посылки 94690426

const _readline = require('readline')

const _reader = _readline.createInterface({
  input: process.stdin,
})

const _inputLines = []

_reader.on('line', (line) => {
  _inputLines.push(line)
})

process.stdin.on('end', solve)

function solve() {
  const areas = _inputLines[1].split(' ').map(Number)

  let epmptiesPositions = []

  for (let i = 0; i < areas.length; i++) {
    if (areas[i] === 0) {
      epmptiesPositions.push(i)
    }
  }

  let emptiesIndex = 0
  const result = []

  for (let i = 0; i < areas.length; i++) {
    const currentDiff = Math.abs(i - epmptiesPositions[emptiesIndex])

    if (epmptiesPositions[emptiesIndex + 1] === undefined) {
      result.push(currentDiff)
      continue
    }

    const nextDiff = Math.abs(i - epmptiesPositions[emptiesIndex + 1])

    if (currentDiff > nextDiff) {
      result.push(nextDiff)
      emptiesIndex++
    } else {
      result.push(currentDiff)
    }
  }

  console.log(result.join(' '))
}
